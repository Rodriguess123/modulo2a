# Exercício para entrega na SEMANA 2 - referente à etapa 1 (`SEMANA01/02_TUTORIAL`)

## Descrição
Adapte os códigos e documentos apresentado na etapa do tutorial da semana 1 para construir seu currículo em uma página HTML que seja servida via Node.JS 


## Forma de entrega
- Publique a sua solução no seu Github pessoal (criado com o e-mail Inteli conforme instruído no tutorial da Semana 1)
- Na resposta ao card na Adalove, inclua o link para o seu Github